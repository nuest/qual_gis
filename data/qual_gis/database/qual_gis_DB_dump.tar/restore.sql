--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.1
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public."~TMPCLP60511_tblAbstractdoi";
DROP INDEX public."wos_tblWOSdoi";
DROP INDEX public.main_qual_gis_fid2;
DROP INDEX public."main_qual_gis_FID";
DROP INDEX public."gis_application_idGIS_method";
DROP INDEX public."geovisual_idGeoVisualization";
DROP INDEX public."geodatabase_idGeodatabase";
DROP INDEX public."abstract_tblAbstractWOS";
ALTER TABLE ONLY public."~TMPCLP60511" DROP CONSTRAINT "~TMPCLP60511_pkey";
ALTER TABLE ONLY public.wos DROP CONSTRAINT wos_pkey;
ALTER TABLE ONLY public.tbl_online_adresses DROP CONSTRAINT tbl_online_adresses_pkey;
ALTER TABLE ONLY public.qual_gis_transfer DROP CONSTRAINT qual_gis_transfer_pkey;
ALTER TABLE ONLY public.qual_data DROP CONSTRAINT qual_data_pkey;
ALTER TABLE ONLY public.qual_analyse DROP CONSTRAINT qual_analyse_pkey;
ALTER TABLE ONLY public.main_qual_gis DROP CONSTRAINT main_qual_gis_pkey;
ALTER TABLE ONLY public.gis_software DROP CONSTRAINT gis_software_pkey;
ALTER TABLE ONLY public.gis_application DROP CONSTRAINT gis_application_pkey;
ALTER TABLE ONLY public.geovisual DROP CONSTRAINT geovisual_pkey;
ALTER TABLE ONLY public.geodatabase DROP CONSTRAINT geodatabase_pkey;
ALTER TABLE ONLY public.countries DROP CONSTRAINT countries_pkey;
ALTER TABLE ONLY public.caqdas DROP CONSTRAINT caqdas_pkey;
ALTER TABLE ONLY public.abstract DROP CONSTRAINT abstract_pkey;
DROP TABLE public."~TMPCLP60511";
DROP TABLE public."~TMPCLP17901";
DROP TABLE public.wos;
DROP TABLE public.tbl_online_adresses;
DROP TABLE public.qual_gis_transfer;
DROP TABLE public.qual_data;
DROP TABLE public.qual_analyse;
DROP TABLE public.main_qual_gis;
DROP TABLE public.gis_software;
DROP TABLE public.gis_application;
DROP TABLE public.geovisual;
DROP TABLE public.geodatabase;
DROP TABLE public.countries;
DROP TABLE public.caqdas;
DROP TABLE public.abstract;
DROP OPERATOR FAMILY public.varchar_ops USING gin;
DROP OPERATOR FAMILY public.varbit_ops USING gin;
DROP OPERATOR FAMILY public.timetz_ops USING gin;
DROP OPERATOR FAMILY public.timestamptz_ops USING gin;
DROP OPERATOR FAMILY public.timestamp_ops USING gin;
DROP OPERATOR FAMILY public.time_ops USING gin;
DROP OPERATOR FAMILY public.text_ops USING gin;
DROP OPERATOR FAMILY public.oid_ops USING gin;
DROP OPERATOR FAMILY public.numeric_ops USING gin;
DROP OPERATOR FAMILY public.money_ops USING gin;
DROP OPERATOR FAMILY public.macaddr_ops USING gin;
DROP OPERATOR FAMILY public.ltree_ops USING btree;
DROP OPERATOR FAMILY public.interval_ops USING gin;
DROP OPERATOR FAMILY public.int8_ops USING gin;
DROP OPERATOR FAMILY public.int4_ops USING gin;
DROP OPERATOR FAMILY public.int2_ops USING gin;
DROP OPERATOR FAMILY public.inet_ops USING gin;
DROP OPERATOR FAMILY public.hash_hstore_ops USING hash;
DROP OPERATOR FAMILY public.gist_ltree_ops USING gist;
DROP OPERATOR FAMILY public.gist_hstore_ops USING gist;
DROP OPERATOR FAMILY public.gist_cube_ops USING gist;
DROP OPERATOR FAMILY public.gist__ltree_ops USING gist;
DROP OPERATOR FAMILY public.gist__intbig_ops USING gist;
DROP OPERATOR FAMILY public.gist__int_ops USING gist;
DROP OPERATOR FAMILY public.gin_hstore_ops USING gin;
DROP OPERATOR FAMILY public.gin__int_ops USING gin;
DROP OPERATOR FAMILY public.float8_ops USING gin;
DROP OPERATOR FAMILY public.float4_ops USING gin;
DROP OPERATOR FAMILY public.date_ops USING gin;
DROP OPERATOR FAMILY public.cube_ops USING btree;
DROP OPERATOR FAMILY public.citext_ops USING hash;
DROP OPERATOR FAMILY public.citext_ops USING btree;
DROP OPERATOR FAMILY public.cidr_ops USING gin;
DROP OPERATOR FAMILY public.char_ops USING gin;
DROP OPERATOR FAMILY public.bytea_ops USING gin;
DROP OPERATOR FAMILY public.btree_hstore_ops USING btree;
DROP OPERATOR FAMILY public.bit_ops USING gin;
DROP EXTENSION xml2;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION unaccent;
DROP EXTENSION tablefunc;
DROP EXTENSION pgstattuple;
DROP EXTENSION pgrowlocks;
DROP EXTENSION pgcrypto;
DROP EXTENSION pg_trgm;
DROP EXTENSION pg_stat_statements;
DROP EXTENSION ltree;
DROP EXTENSION intarray;
DROP EXTENSION hstore;
DROP EXTENSION fuzzystrmatch;
DROP EXTENSION earthdistance;
DROP EXTENSION dict_xsyn;
DROP EXTENSION dict_int;
DROP EXTENSION dblink;
DROP EXTENSION cube;
DROP EXTENSION citext;
DROP EXTENSION btree_gist;
DROP EXTENSION btree_gin;
DROP EXTENSION plv8;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: plv8; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plv8 WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plv8; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plv8 IS 'PL/JavaScript (v8) trusted procedural language';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: cube; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS cube WITH SCHEMA public;


--
-- Name: EXTENSION cube; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION cube IS 'data type for multidimensional cubes';


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: dict_int; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dict_int WITH SCHEMA public;


--
-- Name: EXTENSION dict_int; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_int IS 'text search dictionary template for integers';


--
-- Name: dict_xsyn; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dict_xsyn WITH SCHEMA public;


--
-- Name: EXTENSION dict_xsyn; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_xsyn IS 'text search dictionary template for extended synonym processing';


--
-- Name: earthdistance; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS earthdistance WITH SCHEMA public;


--
-- Name: EXTENSION earthdistance; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION earthdistance IS 'calculate great-circle distances on the surface of the Earth';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: intarray; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS intarray WITH SCHEMA public;


--
-- Name: EXTENSION intarray; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION intarray IS 'functions, operators, and index support for 1-D arrays of integers';


--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: pgrowlocks; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgrowlocks WITH SCHEMA public;


--
-- Name: EXTENSION pgrowlocks; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgrowlocks IS 'show row-level locking information';


--
-- Name: pgstattuple; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgstattuple WITH SCHEMA public;


--
-- Name: EXTENSION pgstattuple; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgstattuple IS 'show tuple-level statistics';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: xml2; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS xml2 WITH SCHEMA public;


--
-- Name: EXTENSION xml2; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION xml2 IS 'XPath querying and XSLT';


SET search_path = public, pg_catalog;

--
-- Name: bit_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY bit_ops USING gin;


ALTER OPERATOR FAMILY public.bit_ops USING gin OWNER TO postgres;

--
-- Name: btree_hstore_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY btree_hstore_ops USING btree;


ALTER OPERATOR FAMILY public.btree_hstore_ops USING btree OWNER TO postgres;

--
-- Name: bytea_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY bytea_ops USING gin;


ALTER OPERATOR FAMILY public.bytea_ops USING gin OWNER TO postgres;

--
-- Name: char_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY char_ops USING gin;


ALTER OPERATOR FAMILY public.char_ops USING gin OWNER TO postgres;

--
-- Name: cidr_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY cidr_ops USING gin;


ALTER OPERATOR FAMILY public.cidr_ops USING gin OWNER TO postgres;

--
-- Name: citext_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY citext_ops USING btree;


ALTER OPERATOR FAMILY public.citext_ops USING btree OWNER TO postgres;

--
-- Name: citext_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY citext_ops USING hash;


ALTER OPERATOR FAMILY public.citext_ops USING hash OWNER TO postgres;

--
-- Name: cube_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY cube_ops USING btree;


ALTER OPERATOR FAMILY public.cube_ops USING btree OWNER TO postgres;

--
-- Name: date_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY date_ops USING gin;


ALTER OPERATOR FAMILY public.date_ops USING gin OWNER TO postgres;

--
-- Name: float4_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY float4_ops USING gin;


ALTER OPERATOR FAMILY public.float4_ops USING gin OWNER TO postgres;

--
-- Name: float8_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY float8_ops USING gin;


ALTER OPERATOR FAMILY public.float8_ops USING gin OWNER TO postgres;

--
-- Name: gin__int_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gin__int_ops USING gin;


ALTER OPERATOR FAMILY public.gin__int_ops USING gin OWNER TO postgres;

--
-- Name: gin_hstore_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gin_hstore_ops USING gin;


ALTER OPERATOR FAMILY public.gin_hstore_ops USING gin OWNER TO postgres;

--
-- Name: gist__int_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist__int_ops USING gist;


ALTER OPERATOR FAMILY public.gist__int_ops USING gist OWNER TO postgres;

--
-- Name: gist__intbig_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist__intbig_ops USING gist;


ALTER OPERATOR FAMILY public.gist__intbig_ops USING gist OWNER TO postgres;

--
-- Name: gist__ltree_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist__ltree_ops USING gist;


ALTER OPERATOR FAMILY public.gist__ltree_ops USING gist OWNER TO postgres;

--
-- Name: gist_cube_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist_cube_ops USING gist;


ALTER OPERATOR FAMILY public.gist_cube_ops USING gist OWNER TO postgres;

--
-- Name: gist_hstore_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist_hstore_ops USING gist;


ALTER OPERATOR FAMILY public.gist_hstore_ops USING gist OWNER TO postgres;

--
-- Name: gist_ltree_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY gist_ltree_ops USING gist;


ALTER OPERATOR FAMILY public.gist_ltree_ops USING gist OWNER TO postgres;

--
-- Name: hash_hstore_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY hash_hstore_ops USING hash;


ALTER OPERATOR FAMILY public.hash_hstore_ops USING hash OWNER TO postgres;

--
-- Name: inet_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY inet_ops USING gin;


ALTER OPERATOR FAMILY public.inet_ops USING gin OWNER TO postgres;

--
-- Name: int2_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY int2_ops USING gin;


ALTER OPERATOR FAMILY public.int2_ops USING gin OWNER TO postgres;

--
-- Name: int4_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY int4_ops USING gin;


ALTER OPERATOR FAMILY public.int4_ops USING gin OWNER TO postgres;

--
-- Name: int8_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY int8_ops USING gin;


ALTER OPERATOR FAMILY public.int8_ops USING gin OWNER TO postgres;

--
-- Name: interval_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY interval_ops USING gin;


ALTER OPERATOR FAMILY public.interval_ops USING gin OWNER TO postgres;

--
-- Name: ltree_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY ltree_ops USING btree;


ALTER OPERATOR FAMILY public.ltree_ops USING btree OWNER TO postgres;

--
-- Name: macaddr_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY macaddr_ops USING gin;


ALTER OPERATOR FAMILY public.macaddr_ops USING gin OWNER TO postgres;

--
-- Name: money_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY money_ops USING gin;


ALTER OPERATOR FAMILY public.money_ops USING gin OWNER TO postgres;

--
-- Name: numeric_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY numeric_ops USING gin;


ALTER OPERATOR FAMILY public.numeric_ops USING gin OWNER TO postgres;

--
-- Name: oid_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY oid_ops USING gin;


ALTER OPERATOR FAMILY public.oid_ops USING gin OWNER TO postgres;

--
-- Name: text_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY text_ops USING gin;


ALTER OPERATOR FAMILY public.text_ops USING gin OWNER TO postgres;

--
-- Name: time_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY time_ops USING gin;


ALTER OPERATOR FAMILY public.time_ops USING gin OWNER TO postgres;

--
-- Name: timestamp_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY timestamp_ops USING gin;


ALTER OPERATOR FAMILY public.timestamp_ops USING gin OWNER TO postgres;

--
-- Name: timestamptz_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY timestamptz_ops USING gin;


ALTER OPERATOR FAMILY public.timestamptz_ops USING gin OWNER TO postgres;

--
-- Name: timetz_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY timetz_ops USING gin;


ALTER OPERATOR FAMILY public.timetz_ops USING gin OWNER TO postgres;

--
-- Name: varbit_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY varbit_ops USING gin;


ALTER OPERATOR FAMILY public.varbit_ops USING gin OWNER TO postgres;

--
-- Name: varchar_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY varchar_ops USING gin;


ALTER OPERATOR FAMILY public.varchar_ops USING gin OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: abstract; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE abstract (
    "ID" integer NOT NULL,
    abstract text,
    doi character varying(255),
    "WOS" character varying(255),
    year double precision,
    titel character varying(255)
);


ALTER TABLE abstract OWNER TO mzsrnrwj;

--
-- Name: caqdas; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE caqdas (
    "idCAQDAS" integer NOT NULL,
    "CAQDAS_Typ" character varying(255),
    "Description" character varying(255)
);


ALTER TABLE caqdas OWNER TO mzsrnrwj;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE countries (
    "idCountries" integer NOT NULL,
    "Country" character varying(255),
    "Continent" character varying(255)
);


ALTER TABLE countries OWNER TO mzsrnrwj;

--
-- Name: geodatabase; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE geodatabase (
    "idGeodatabase" integer NOT NULL,
    "Geodatabase" character varying(255)
);


ALTER TABLE geodatabase OWNER TO mzsrnrwj;

--
-- Name: geovisual; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE geovisual (
    "idGeoVisualization" integer NOT NULL,
    "Visualization" character varying(255),
    "Feld1" character varying(255)
);


ALTER TABLE geovisual OWNER TO mzsrnrwj;

--
-- Name: gis_application; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE gis_application (
    "idGIS_Typ" integer NOT NULL,
    "Typ" character varying(255),
    description character varying(255)
);


ALTER TABLE gis_application OWNER TO mzsrnrwj;

--
-- Name: gis_software; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE gis_software (
    id_gis integer NOT NULL,
    "GIS_Software" character varying(255),
    open_source boolean DEFAULT false,
    "Description" character varying(255)
);


ALTER TABLE gis_software OWNER TO mzsrnrwj;

--
-- Name: main_qual_gis; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE main_qual_gis (
    id_qualgis integer NOT NULL,
    "fidGIS" integer DEFAULT 0,
    "fidCAQDAS" integer DEFAULT 0,
    "fidQualAnalyse" integer DEFAULT 0,
    "fidQualGIS_transfer" integer DEFAULT 0,
    fid_citavi integer DEFAULT 0,
    "fidCountries" text,
    "Qual_Context" boolean DEFAULT false,
    "Latitude" double precision DEFAULT 0,
    "Longtitude" double precision DEFAULT 0,
    "Research_field" text,
    "Institution" text,
    "PDF" boolean DEFAULT false,
    "Abstract only" boolean DEFAULT false,
    "fidQualData" text,
    "fidGIS_app" text,
    "fidGeoVis" text,
    "fidGeodatabase" text,
    "Note" text
);


ALTER TABLE main_qual_gis OWNER TO mzsrnrwj;

--
-- Name: qual_analyse; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE qual_analyse (
    "idQualAnalyse" integer NOT NULL,
    analyse_method character varying(255),
    "Description" character varying(255)
);


ALTER TABLE qual_analyse OWNER TO mzsrnrwj;

--
-- Name: qual_data; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE qual_data (
    "idQualData" integer NOT NULL,
    "Qual_Data" character varying(255)
);


ALTER TABLE qual_data OWNER TO mzsrnrwj;

--
-- Name: qual_gis_transfer; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE qual_gis_transfer (
    "idQualGIS_transfer" integer NOT NULL,
    "QualGIS_transfer" character varying(255),
    "Description" character varying(255)
);


ALTER TABLE qual_gis_transfer OWNER TO mzsrnrwj;

--
-- Name: tbl_online_adresses; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE tbl_online_adresses (
    id_citavi double precision NOT NULL,
    "Online_Adress" character varying(255)
);


ALTER TABLE tbl_online_adresses OWNER TO mzsrnrwj;

--
-- Name: wos; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE wos (
    id_citavi integer NOT NULL,
    author character varying(255),
    year double precision,
    title character varying(255),
    journal_name character varying(255),
    journal_volume double precision,
    number character varying(255),
    page_range character varying(255),
    doi character varying(255),
    "WOS" character varying(255),
    no_authors double precision,
    "fidGIS_Method" integer DEFAULT 0
);


ALTER TABLE wos OWNER TO mzsrnrwj;

--
-- Name: ~TMPCLP17901; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE "~TMPCLP17901" (
    "Fehler" character varying(255),
    "Feld" character varying(255),
    "Zeile" integer
);


ALTER TABLE "~TMPCLP17901" OWNER TO mzsrnrwj;

--
-- Name: ~TMPCLP60511; Type: TABLE; Schema: public; Owner: mzsrnrwj
--

CREATE TABLE "~TMPCLP60511" (
    "ID" integer NOT NULL,
    "Abstract" text,
    doi character varying(255),
    year double precision
);


ALTER TABLE "~TMPCLP60511" OWNER TO mzsrnrwj;

--
-- Data for Name: abstract; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY abstract ("ID", abstract, doi, "WOS", year, titel) FROM stdin;
\.
COPY abstract ("ID", abstract, doi, "WOS", year, titel) FROM '$$PATH$$/3094.dat';

--
-- Data for Name: caqdas; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY caqdas ("idCAQDAS", "CAQDAS_Typ", "Description") FROM stdin;
\.
COPY caqdas ("idCAQDAS", "CAQDAS_Typ", "Description") FROM '$$PATH$$/3095.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY countries ("idCountries", "Country", "Continent") FROM stdin;
\.
COPY countries ("idCountries", "Country", "Continent") FROM '$$PATH$$/3096.dat';

--
-- Data for Name: geodatabase; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY geodatabase ("idGeodatabase", "Geodatabase") FROM stdin;
\.
COPY geodatabase ("idGeodatabase", "Geodatabase") FROM '$$PATH$$/3097.dat';

--
-- Data for Name: geovisual; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY geovisual ("idGeoVisualization", "Visualization", "Feld1") FROM stdin;
\.
COPY geovisual ("idGeoVisualization", "Visualization", "Feld1") FROM '$$PATH$$/3098.dat';

--
-- Data for Name: gis_application; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY gis_application ("idGIS_Typ", "Typ", description) FROM stdin;
\.
COPY gis_application ("idGIS_Typ", "Typ", description) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: gis_software; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY gis_software (id_gis, "GIS_Software", open_source, "Description") FROM stdin;
\.
COPY gis_software (id_gis, "GIS_Software", open_source, "Description") FROM '$$PATH$$/3100.dat';

--
-- Data for Name: main_qual_gis; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY main_qual_gis (id_qualgis, "fidGIS", "fidCAQDAS", "fidQualAnalyse", "fidQualGIS_transfer", fid_citavi, "fidCountries", "Qual_Context", "Latitude", "Longtitude", "Research_field", "Institution", "PDF", "Abstract only", "fidQualData", "fidGIS_app", "fidGeoVis", "fidGeodatabase", "Note") FROM stdin;
\.
COPY main_qual_gis (id_qualgis, "fidGIS", "fidCAQDAS", "fidQualAnalyse", "fidQualGIS_transfer", fid_citavi, "fidCountries", "Qual_Context", "Latitude", "Longtitude", "Research_field", "Institution", "PDF", "Abstract only", "fidQualData", "fidGIS_app", "fidGeoVis", "fidGeodatabase", "Note") FROM '$$PATH$$/3101.dat';

--
-- Data for Name: qual_analyse; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY qual_analyse ("idQualAnalyse", analyse_method, "Description") FROM stdin;
\.
COPY qual_analyse ("idQualAnalyse", analyse_method, "Description") FROM '$$PATH$$/3102.dat';

--
-- Data for Name: qual_data; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY qual_data ("idQualData", "Qual_Data") FROM stdin;
\.
COPY qual_data ("idQualData", "Qual_Data") FROM '$$PATH$$/3103.dat';

--
-- Data for Name: qual_gis_transfer; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY qual_gis_transfer ("idQualGIS_transfer", "QualGIS_transfer", "Description") FROM stdin;
\.
COPY qual_gis_transfer ("idQualGIS_transfer", "QualGIS_transfer", "Description") FROM '$$PATH$$/3104.dat';

--
-- Data for Name: tbl_online_adresses; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY tbl_online_adresses (id_citavi, "Online_Adress") FROM stdin;
\.
COPY tbl_online_adresses (id_citavi, "Online_Adress") FROM '$$PATH$$/3105.dat';

--
-- Data for Name: wos; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY wos (id_citavi, author, year, title, journal_name, journal_volume, number, page_range, doi, "WOS", no_authors, "fidGIS_Method") FROM stdin;
\.
COPY wos (id_citavi, author, year, title, journal_name, journal_volume, number, page_range, doi, "WOS", no_authors, "fidGIS_Method") FROM '$$PATH$$/3106.dat';

--
-- Data for Name: ~TMPCLP17901; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY "~TMPCLP17901" ("Fehler", "Feld", "Zeile") FROM stdin;
\.
COPY "~TMPCLP17901" ("Fehler", "Feld", "Zeile") FROM '$$PATH$$/3107.dat';

--
-- Data for Name: ~TMPCLP60511; Type: TABLE DATA; Schema: public; Owner: mzsrnrwj
--

COPY "~TMPCLP60511" ("ID", "Abstract", doi, year) FROM stdin;
\.
COPY "~TMPCLP60511" ("ID", "Abstract", doi, year) FROM '$$PATH$$/3108.dat';

--
-- Name: abstract_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY abstract
    ADD CONSTRAINT abstract_pkey PRIMARY KEY ("ID");


--
-- Name: caqdas_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY caqdas
    ADD CONSTRAINT caqdas_pkey PRIMARY KEY ("idCAQDAS");


--
-- Name: countries_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY ("idCountries");


--
-- Name: geodatabase_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY geodatabase
    ADD CONSTRAINT geodatabase_pkey PRIMARY KEY ("idGeodatabase");


--
-- Name: geovisual_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY geovisual
    ADD CONSTRAINT geovisual_pkey PRIMARY KEY ("idGeoVisualization");


--
-- Name: gis_application_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY gis_application
    ADD CONSTRAINT gis_application_pkey PRIMARY KEY ("idGIS_Typ");


--
-- Name: gis_software_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY gis_software
    ADD CONSTRAINT gis_software_pkey PRIMARY KEY (id_gis);


--
-- Name: main_qual_gis_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY main_qual_gis
    ADD CONSTRAINT main_qual_gis_pkey PRIMARY KEY (id_qualgis);


--
-- Name: qual_analyse_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY qual_analyse
    ADD CONSTRAINT qual_analyse_pkey PRIMARY KEY ("idQualAnalyse");


--
-- Name: qual_data_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY qual_data
    ADD CONSTRAINT qual_data_pkey PRIMARY KEY ("idQualData");


--
-- Name: qual_gis_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY qual_gis_transfer
    ADD CONSTRAINT qual_gis_transfer_pkey PRIMARY KEY ("idQualGIS_transfer");


--
-- Name: tbl_online_adresses_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY tbl_online_adresses
    ADD CONSTRAINT tbl_online_adresses_pkey PRIMARY KEY (id_citavi);


--
-- Name: wos_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY wos
    ADD CONSTRAINT wos_pkey PRIMARY KEY (id_citavi);


--
-- Name: ~TMPCLP60511_pkey; Type: CONSTRAINT; Schema: public; Owner: mzsrnrwj
--

ALTER TABLE ONLY "~TMPCLP60511"
    ADD CONSTRAINT "~TMPCLP60511_pkey" PRIMARY KEY ("ID");


--
-- Name: abstract_tblAbstractWOS; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "abstract_tblAbstractWOS" ON abstract USING btree ("WOS");


--
-- Name: geodatabase_idGeodatabase; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "geodatabase_idGeodatabase" ON geodatabase USING btree ("idGeodatabase");


--
-- Name: geovisual_idGeoVisualization; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "geovisual_idGeoVisualization" ON geovisual USING btree ("idGeoVisualization");


--
-- Name: gis_application_idGIS_method; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "gis_application_idGIS_method" ON gis_application USING btree ("idGIS_Typ");


--
-- Name: main_qual_gis_FID; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "main_qual_gis_FID" ON main_qual_gis USING btree ("fidGIS");


--
-- Name: main_qual_gis_fid2; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX main_qual_gis_fid2 ON main_qual_gis USING btree ("fidQualGIS_transfer");


--
-- Name: wos_tblWOSdoi; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "wos_tblWOSdoi" ON wos USING btree (doi);


--
-- Name: ~TMPCLP60511_tblAbstractdoi; Type: INDEX; Schema: public; Owner: mzsrnrwj
--

CREATE INDEX "~TMPCLP60511_tblAbstractdoi" ON "~TMPCLP60511" USING btree (doi);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

